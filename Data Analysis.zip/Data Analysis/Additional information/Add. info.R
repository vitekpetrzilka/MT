
################################################################################

# GU countries

library(readr)

GU <- read_csv("Data/GU.csv")

GU_scope <- union(unique(GU$exporter),
                  unique(GU$importer))

library(countrycode)
library(dplyr)
library(writexl)

GU_df <- tibble("iso3c" = GU_scope,
                "Country" = GU_scope) %>% 
  mutate(Country = countrycode(Country, origin = "iso3c", destination = "country.name"))

write_xlsx(GU_df, "Additional information/GU countries.xlsx")

################################################################################

# ITPD-S countries

library(arrow)

dataset_path <- "C:/Users/vitek/Desktop/ITPD_S_R1.1_no_names.csv"

ds <- open_dataset(dataset_path, format = "csv")

ITPD_S_scope <- ds %>%
  filter(broad_sector != "Services") %>%
  rename(exporter = exporter_iso3,
         importer = importer_iso3) %>% 
  select(exporter, importer) %>% 
  collect()

ITPD_S_scope <- union(unique(ITPD_S_scope$exporter),
                      unique(ITPD_S_scope$importer))

ITPD_S_df <- tibble("iso3c" = ITPD_S_scope,
                    "Country" = ITPD_S_scope) %>% 
  mutate(Country = countrycode(Country, origin = "iso3c", destination = "country.name"))

write_xlsx(ITPD_S_df, "Additional information/ITPD-S countries.xlsx")

################################################################################

# GU50 scope

cz_trade <- GU %>%
  filter(exporter == "CZE" | importer == "CZE") %>%
  mutate(partner = if_else(exporter == "CZE", importer, exporter)) %>%
  group_by(partner) %>%
  summarise(total_trade = sum(trade, na.rm = TRUE)) %>%
  arrange(desc(total_trade)) %>%
  slice_head(n = 49)

# Saving iso3c of TOP partners as a vector

cz_top49 <- cz_trade$partner

# SRB do not exist in all periods

cz_top48 <- setdiff(cz_top49, "SRB")

scope <- c(cz_top48, "CZE", "RoW")

scope_df <- tibble("iso3c" = scope,
                   "Country" = scope) %>% 
  mutate(Country = countrycode(Country, origin = "iso3c", destination = "country.name"),
         Country = if_else(iso3c == "RoW", "Rest of the World", Country))

write_xlsx(scope_df, "Additional information/Panel scope.xlsx")

################################################################################

# Aggregated industries

## 1. Agriculture

dataset_path <- "C:/Users/vitek/Desktop/ITPD_S_R1.1_no_names.csv"

ds <- open_dataset(dataset_path, format = "csv")

ITPD_S_scope <- ds %>%
  filter(broad_sector == "Agriculture") %>%
  rename(exporter = exporter_iso3,
         importer = importer_iso3) %>% 
  select(exporter, importer) %>% 
  collect()

ITPD_S_scope <- union(unique(ITPD_S_scope$exporter),
                      unique(ITPD_S_scope$importer))

# Aggregated industries

Man_industries <- read_csv("C:/Users/vitek/Desktop/itpd_e_r02_manuf_isic.csv")
write_xlsx(Man_industries, "C:/Users/vitek/Desktop/itpd_e_r02_manuf_isic.xlsx")

Mae_industries <- read_csv("C:/Users/vitek/Desktop/itpd_e_r02_me_isic.csv")
write_xlsx(Mae_industries, "C:/Users/vitek/Desktop/itpd_e_r02_me_isic.xlsx")

################################################################################




